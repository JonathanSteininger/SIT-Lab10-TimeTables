Connection String: Server=localhost;Database=studenttimetable;Uid=student;Pwd=secret;

Saves the results to "timetables3.xlsx"

I have added the database sql file to the zip. you just need to add it to an sql server.